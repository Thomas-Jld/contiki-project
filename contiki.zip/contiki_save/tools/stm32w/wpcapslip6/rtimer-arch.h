#ifndef __RTIMER_ARCH_H__
#define __RTIMER_ARCH_H__


#endif /* __RTIMER_ARCH_H__ */
